﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form



    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.buttonAddTextBox = New System.Windows.Forms.Button()
        Me.buttonLessTextBox = New System.Windows.Forms.Button()
        Me.labelCounter = New System.Windows.Forms.Label()
        Me.panelContainer = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'buttonAddTextBox
        '
        Me.buttonAddTextBox.Location = New System.Drawing.Point(12, 126)
        Me.buttonAddTextBox.Name = "buttonAddTextBox"
        Me.buttonAddTextBox.Size = New System.Drawing.Size(302, 88)
        Me.buttonAddTextBox.TabIndex = 0
        Me.buttonAddTextBox.Text = "Más TextBox"
        Me.buttonAddTextBox.UseVisualStyleBackColor = True
        '
        'buttonLessTextBox
        '
        Me.buttonLessTextBox.Location = New System.Drawing.Point(12, 220)
        Me.buttonLessTextBox.Name = "buttonLessTextBox"
        Me.buttonLessTextBox.Size = New System.Drawing.Size(302, 90)
        Me.buttonLessTextBox.TabIndex = 1
        Me.buttonLessTextBox.Text = "Menos TextBox"
        Me.buttonLessTextBox.UseVisualStyleBackColor = True
        '
        'labelCounter
        '
        Me.labelCounter.AutoSize = True
        Me.labelCounter.Location = New System.Drawing.Point(521, 13)
        Me.labelCounter.Name = "labelCounter"
        Me.labelCounter.Size = New System.Drawing.Size(0, 15)
        Me.labelCounter.TabIndex = 2
        '
        'panelContainer
        '
        Me.panelContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelContainer.Location = New System.Drawing.Point(320, 32)
        Me.panelContainer.Name = "panelContainer"
        Me.panelContainer.Size = New System.Drawing.Size(390, 377)
        Me.panelContainer.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(872, 439)
        Me.Controls.Add(Me.panelContainer)
        Me.Controls.Add(Me.labelCounter)
        Me.Controls.Add(Me.buttonLessTextBox)
        Me.Controls.Add(Me.buttonAddTextBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents buttonAddTextBox As Button
    Friend WithEvents buttonLessTextBox As Button
    Friend WithEvents labelCounter As Label
    Friend WithEvents panelContainer As Panel
End Class
