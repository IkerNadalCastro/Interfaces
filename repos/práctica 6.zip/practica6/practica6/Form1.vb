﻿Public Class Form1

    Private Sub btn_masTextBox_Click(sender As Object, e As EventArgs) Handles buttonAddTextBox.Click

        Dim myTextBox = New TextBox
        Dim text = New Label

        If panelContainer.Controls.Count > 18 Then

            Exit Sub

        End If

        myTextBox.Top = (panelContainer.Controls.Count / 2) * (myTextBox.Height + 10) + 10
        text.Top = (panelContainer.Controls.Count / 2) * (text.Height + 10) + 10
        myTextBox.Left = 150

        text.ForeColor = Color.Red
        myTextBox.ForeColor = Color.FromArgb(RGB(Rnd() * 255, Rnd() * 255, Rnd() * 255))

        AddHandler myTextBox.DoubleClick, AddressOf miTexto

        panelContainer.Controls.Add(text)
        panelContainer.Controls.Add(myTextBox)
        myTextBox.Name = "" & panelContainer.Controls.Count / 2

        labelCounter.Text = "Nº de TextBox " & panelContainer.Controls.Count / 2

        text.Text = "Nº de TextBox " & (panelContainer.Controls.Count / 2)

    End Sub

    Private Sub btn_menosTextBox_Click(sender As Object, e As EventArgs) Handles buttonLessTextBox.Click

        If panelContainer.Controls.Count = 0 Then

            Exit Sub

        End If

        panelContainer.Controls.RemoveAt(panelContainer.Controls.Count - 1)
        panelContainer.Controls.RemoveAt(panelContainer.Controls.Count - 1)
        labelCounter.Text = "Nº de TextBox " & panelContainer.Controls.Count / 2

    End Sub

    Private Sub miTexto(objeto As Object, evento As EventArgs)

        Dim text As TextBox = objeto

        If text.Text = "" Then

            Exit Sub

        End If

        MessageBox.Show("Contenido de mi TexBox " + text.Name + " es " + text.Text)

    End Sub

End Class
